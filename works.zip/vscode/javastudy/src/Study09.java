public class Study09 {
    public static void main(String[] ar) {  
        //int 단 = 1;
        for(int 단 = 1; 단 <= 9; 단++) {
            for(int i = 1; i <= 9; i++) {
            System.out.println(1 + " * " + i + " = " + (단 * i) );
            }   
        }
    }
}
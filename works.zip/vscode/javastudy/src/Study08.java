public class Study08 {
    public static void main(String[] args) {
        int a = 3;
        switch(a) {
            case 1 :
                System.out.println("1");
            case 2 :
                System.out.println("2");
            case 3 :
                System.out.println("3");
                break;
            case 4 :
                System.out.println("4");
            case 5 :
                System.out.println("5");
                break;

                default:
                System.out.println(x:"그외의값");
        }
    }
}


import java.util.ArrayList;
import java.util.List;

public class Study23 {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        //list.add(1);
        list.add("1"); // 0
        //list.add(true);
        list.add("일"); // 문자를 담을 수 있는 리스트가 됨, 1
        list.add("one"); // 2

        // 문제. 영어로 되어있는 1을 출력하시오.
        // System.out.println(list.get(2));
        // 적어둔 리스트 순서대로 0, 1, 2 이렇게 됨. 그래서 one을 출력하려면 해당 순번인 2를 적용

        // 문제2. 리스트에서 인덱스 1를 삭제 후 영어로 되어있는 값을 출력하시오.
        list.remove(1);
        System.out.println(list.get(1));
        // 리스트 하나를 삭제해서 one의 순번이 앞당겨져서 1로 변경
    }
}

class DataA {

    int no;
    String name;
    String pwd;
    int age;

    // get, set(값을 넣음)
    
    public int getNo() {
        return this.no;
    }

    public void setNo() {
        this.no = no;
    }

}
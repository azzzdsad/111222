import java.util.Scanner;
        // q. 자판기 프로그램 만들기
        // 1. 반복 입력 받을 수 있도록 (반복문과 입력(System.in) 필수)
        // 2. 프로그램 시작 시 인사말이 되도록 할 것.
        // 3. 프로그램 종료를 위해서 입력으로 "EXIT" 값으로 받으면 종료 되도록 할 것.
        
public class S241126 {

    public static void main(String[] args) {
        // 인사말 출력
        System.out.println("안녕하세요. 구매할 상품이 있는지 확인해 주세요.");

        // 음료 종류 및 가격 설정
        String[] drinks = {"코카콜라", "환타", "칠성사이다", "초코에몽"};
        int[] prices = {2400, 2100, 2300, 1400};

        // Scanner 객체 생성(사용자 코드 읽을 준비)
        Scanner scanner = new Scanner(System.in);

        // 프로그램 반복
        while (true) { //
            // 자판기 메뉴 출력
            System.out.println("-----자판기-----");
            for (int i = 0; i < drinks.length; i++) {
                System.out.println((i + 1) + ". " + drinks[i] + " - " + prices[i] + "원");
            }

            // 상품 선택 받기
            System.out.print("구매할 상품의 번호를 입력해 주세요 (종료하려면 EXIT 입력): ");
            String input = scanner.nextLine();  // 사용자의 입력을 받음

            // "EXIT" 입력 시 프로그램 종료
            if (input.equalsIgnoreCase("EXIT")) {
                System.out.println("프로그램을 종료합니다.");
                break;  // while문 종료, 즉 프로그램 종료
            }

            
            try { 
                int choice = Integer.parseInt(input);  // 문자열을 정수로 변환
                if (choice >= 1 && choice <= drinks.length) { // 번호 입력이 숫자일 경우 처리
                    System.out.println("구매 상품: " + drinks[choice - 1]);
                    System.out.println("가격: " + prices[choice - 1] + "원");
                } else {
                    System.out.println("잘못된 번호입니다.");
                }
            } catch (NumberFormatException e) {
                // 숫자가 아닌 값이 들어왔을 때 처리
                System.out.println("올바른 번호를 입력하세요.");
            }
        }
        

        // Scanner 객체 닫기
        scanner.close();
    }
}


// System.out.print("금액을 투입하세요: ");
//                 int amount = scanner.nextInt(); // 금액 입력

//                 // 잔돈 계산
//                 if (amount >= price[pick - 1]) {
//                     int change = amount - price[pick - 1];
//                     System.out.println("잔돈은 " + change + "원 입니다.");
//                 } else {
//                     System.out.println("금액이 부족합니다. 다시 시도해주세요.");
//                     continue; // 금액이 부족하면 음료 선택 화면으로 돌아감
// pick변수 System.out.print("버튼을 눌러 음료를 선택하세요 (1~5): ");
//            int pick = scanner.nextInt(); 사용자 선택때 썼던 pick 변수
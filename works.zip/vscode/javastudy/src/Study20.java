public class Study20 {
    public static void main(String[] args) {
        new Study20_C().run();
    }
}

class Study20_C implements Study20_I {
    @Override //오버라이드를 안 해주면 구현이 불가능
    public void run() {
        System.out.println(txt);
    }
}

interface Study20_I { // 인터페이스에 변수X, 상수O
    final String txt = "인터페이스"; //디폴트부터 쓸 수 있음
    // final 쓰면서 상수 만들 때 변수 명은 대문자로 하는 게 좋음
    // public abstract void a();  = 추상메소드(abstract)는 인터페이스와 함께면 쓰지 않아도 됨

    public void run();

}
public class Study_review_241122 {

    public static void main(String[] args) {
        String o = "O"; 
        String x = "X";  // 1.문자열에 적힐 문자 작성

        String[] 문제1 = new String[10]; // 2.배열의 크기를 정함(ex. 1*5, 5*5 /빙고판처럼)

        for(int i = 0; i < 문제1.length; i++) { // ↓ 3.반복문 사용, 정수 i는  표의 길이보다 작고 1씩 증가한다. (++) 

            if (i%2 == 0) { // (i를 2로 나눈 나머지가 0이면) 짝수면
                문제1[i] = o; // i를 O로 표기하고
            } 
            else {  // 같지 않으면
                문제1[i] = x; // X로 표기하라

            }

        }

    }
 }


 // 도커 서술형 시험-월
 // 자바 객관식 시험-수
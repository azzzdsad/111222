
// 정답지 (강사님ver)


public class Study19 {
    public static void main(String[] args) {
        new S19A().run(); 
        S19A s19a = new S19A(); // S19A=물통, s19a=물 => new=만들다.
        S19B s19b = new S19B();
        // S19A.run();
        // S19B.run();
        s19b.call(s19a, s19b);
    }
}

class S19AB { // this = 자기 자신, 부모는 자식에게 속성을 그대로 물려주고, 물려주면 this는 물려 받은 자식의 이름이 된다.
    public void run() {
        System.out.println("안녕하세요.");
        System.out.println(this + " 안녕하세요.");
    }
}


class S19A extends S19AB { 
    public void call(S19A s19a, S19B s19b) {
        s19a.run(); // S19AB 클래스의 run() 메서드를 상속받아 사용
        s19b.call(s19a, s19b);
    }
}

class S19B extends S19AB {
    public void call(S19A s19a, S19B s19b) {
        s19b.run(); // S19AB 클래스의 run() 메서드를 상속받아 사용
        s19a.call(s19a, s19b);
    }
}
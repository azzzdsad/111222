public class Study15 {
    String o = "O";
    String 빈 = "X";
    public static void main(String[] args) { 
        Study15 클래스 = new Study15();
        // 2차원 배열에 값 넣기
        String[][] 문제1 = 클래스.문제1값();
        // 2차원 배열에 있는 값 확인
        클래스.배열확인(문제1);
    }
    //2차원 배열 문제1에 값을 넣고, 그 값을 확인하는 코드    

    private String[][] 문제1값() { // private = 접근 제어자, 메소드 = 특정 작업을 수행하는 코드 블록
        String[][] 문제1 = new String[10][10]; //10*10 행열로 출력
        // for문=반복문 
        for (int i = 0; i < 문제1.length; i++) { // //  
            for (int j = 0; j < 문제1[i].length; j++) { //// 
                if(j <= i) {
                    문제1[i][j] = o;
                } else {
                    문제1[i][j] = 빈;
                }
            }
        }
        return 문제1;

    }
    //2차원 배열 문제1에 조건에 따라 'o' 또는 '빈' 값을 채워 반환하는 메서드

    private void 배열확인(String[][] 배열) {
        for(int i = 0; i < 배열.length; i++) {
            for(int j = 0; j < 배열[i].length; j++) {
                System.out.print(배열[i][j]);
            }
            System.out.println();
        }
    }

}

// j = i // 제이가 i랑 같을 때까지 
// return = 만들어진 걸 반환

// 2차원 배열의 뜻: 행과 열로 이루어진 데이터를 저장할 수 있는 배열
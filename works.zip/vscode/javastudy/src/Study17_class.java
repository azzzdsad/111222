public class Study17_class {
    public static void main(String[] args) {
        A a = new A();
        System.out.println("x:a."); // 참조 자료형
    }
}

class A {
    public A() {} // 클래스의 기본 생성자, 생성자는 여러 개 만들 수 있음
    public A(int a) {}
    // public A(int a) {} // 위에 쓴 것과 똑같은 생성자를 한 번 더 쓰는 건 안 됨 
    
    public A(int a, int b) {} // 이렇게 쓰는 건 가능
    public String toString() {
        return "A 클래스 객체 생성 완료"; // https://wikidocs.net/214
    }
}


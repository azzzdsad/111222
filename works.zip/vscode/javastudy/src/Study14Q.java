public class Study14Q {
    //내가 문제 풀어봄
    public static void main(String[] args) {
        int[][] a = new int[2][10]; // 2*10 표 생성

        // 첫 번째 행에 O와 X 설정 (O=1, X=0)
        for (int i = 0; i < 10; i++) {
            if (i % 2 == 0) { // 짝수 인덱스는 O(1)
                a[0][i] = 1;
            } else { // 홀수 인덱스는 X(0)
                a[0][i] = 0;
            }
        }

        // 배열 출력
        for (int i = 0; i < 1; i++) { // 첫 번째 행만 출력
            for (int j = 0; j < 10; j++) {
                if (a[i][j] == 1) {
                    System.out.print("O ");
                } else {
                    System.out.print("X ");
                }
            }
            System.out.println();
        }
        
        /*

        + 1차원 배열로 아래의 그림과 같이 넣으시오. 단, 값을 넣을때 for문 사용
        <img src="./images/q/1.png" width="400"></img>
        + 2차원 배열로 아래의 그림과 같이 넣으시오. 단, 값을 넣을때 for문 사용
        <img src="./images/q/2.png" width="300"></img>
        
        */
    }

}
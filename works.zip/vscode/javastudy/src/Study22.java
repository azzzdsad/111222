
import java.util.ArrayList;
import java.util.List;

public class Study22 {
    public static void main(String[] args) {
        List list = new ArrayList<>(); // List와 ArrayList를 사용하려면 import를 반드시 사용
        list.add(1); // =인덱스가 0이 됨
        list.add("1"); // =인덱스가 1이 됨
        list.add(true); // =인덱스가 2가 됨

        // System.out.println(list.get(1) instanceof Integer); //인티저 = 정수 / 
        // System.out.println(list.size());
        
        System.out.println(list.size());

        list.remove(0);
        System.out.println(list.size());
        System.out.println( list.get(0) instanceof String );
    }
}
public class Study02 {
    
}

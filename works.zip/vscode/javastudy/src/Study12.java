public class Study12 {
    public static void main(String[] args) {
        int[][] a = new int[5][5]; // 5*5=25칸의 표가 나옴, new를 쓰면 메모리 할당이 됨 
        a[1][1] = 50; // [1,1] 위치에 있는 50
        a[0][3] = 40;
        a[3][2] = 60;
        // 참고 자료 =  https://docs.google.com/spreadsheets/d/1WJ4XTQQa_DOZyNt63nFNOidPxWb_tFeH0LMPgve8aQs/edit?gid=0#gid=0
    }
}
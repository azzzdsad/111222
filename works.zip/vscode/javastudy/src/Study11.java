public class Study11 {
    public static void main(String[] args) {
        int[] a = new int[5]; // 대괄호에 적은 수만큼 값이 들어갈 수 있는 배열 
        /// 1, 2, 3, 4, 5 배열
        /// 0, 1, 2, 3, 4 << index / 인덱스는 무조건 0부터 시작! 인덱스는 순서가 있음
        /// a[1] >> 아웃풋으로 1 나옴
        /// a[4] >> 5 가 나옴 
        a[0] =1;
        a[1] =2;
        a[2] =3;
        a[3] =4;
        a[4] =5;

        //System.out.println(a[1]); //출력

        int[] b = new int[] {6,7,8,9,10}; // int = 정수, string = 문자 
        //System.out.println(a[3]);
        


        b[0] = 11;
        System.out.println(b[0]); //출력
    }
}

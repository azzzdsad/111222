public class Study01 {

    public static void main(String[] ar) {        
        //static은 메인 메소드, 메소드로 모든 프로그램을 실행 시킴
        //메인 메소드 작성할 때 Run과 재생 버튼이 생김
            System.out.print(1);
            //i:은 자동으로 만들어지는 것, 직접 작성 X
            // 1이라는 것을 i라는 변수에 넣어준다는 뜻

            int a = 1;
            int b;
            b = 2;
            System.out.println(b);

            //★☆★☆ int를 a(명)라는 걸로 만든다. 대입(=)하면 1.
            //★☆★☆ 1이라는 것은 a한테 넣겠다.
            //이름 중복 X



    }
    
}
import java.util.ArrayList;
import java.util.List;

public class Study24 {
    public static void main(String[] args) {
        // ArrayList를 생성하여 DataA 객체를 담을 준비를 합니다.
        List<DataA> list = new ArrayList<>();
        
        // DataA 클래스의 객체를 생성합니다.
        DataA a = new DataA();
        
        // 객체의 no 영역(필드) 값을 10으로 설정합니다.
        a.setNo(10);
        
        // 설정한 DataA 객체를 리스트에 추가합니다.
        list.add(a);
        
        // 리스트에서 첫 번째 객체를 꺼내어 DataA 타입인지 확인하고 결과를 출력합니다.
        System.out.println(list.get(0) instanceof DataA);
    }
}

// DataA 클래스: 정보를 저장하기 위한 사용자 정의 클래스입니다.
class DataA {
    int no;           // 번호를 저장할 영역
    String name;      // 이름을 저장할 영역
    String pwd;       // 비밀번호를 저장할 영역
    int age;          // 나이를 저장할 영역
    
    // 번호를 가져오는 메서드입니다.
    public int getNo() { //get, set = 값을 넣음
        return this.no;
    }
    
    // 번호를 설정하는 메서드입니다.
    public void setNo(int no) {
        this.no = no;
    }
}
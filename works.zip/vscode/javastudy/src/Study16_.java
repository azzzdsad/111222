public class Study16_ {
    String o = "O";
    String 빈 = "X";
    public static void main(String[] args) {
        Study16_ 클래스 = new Study16_();
        // 2차원 배열에 값 넣기
        String[][] 문제1 = 클래스.문제1값();
        // 2차원 배열에 있는 값 확인
        클래스.배열확인(문제1);
        // 클래스.배열확인(클래스.문제1값());
        클래스.배열확인(클래스.문제2값());
        클래스.배열확인(클래스.문제3값());
        클래스.배열확인(클래스.문제4값());
    }
    

    
    private String[][] 문제1값() {
        String[][] 문제1 = new String[10][10]; // 10x10 크기의 2차원 배열을 생성
        for (int i = 0; i < 문제1.length; i++) { 
            // 배열의 각 행을 반복
            for (int j = 0; j < 문제1[i].length; j++) { 
                // 각 열을 반복
                if(j <= i) { 
                    // 열 번호가 행 번호보다 작거나 같으면 'o'를 넣고
                    문제1[i][j] = o; 
                } else { 
                    // 그렇지 않으면 '빈'을 넣어
                    문제1[i][j] = 빈; 
                }
            }
        }
        return 문제1; // 만들어진 2차원 배열 문제1을 반환
    }
    

    private String[][] 문제2값() {
        String[][] 문제2 = new String[10][10];
        for(int i = 0; i < 문제2.length; i++) {
            for(int j = 0; j < 문제2[i].length; j++) {
                // if(j < i) {
                //     문제2[i][j] = 빈;
                // } else {
                //     문제2[i][j] = o;
                // }
                문제2[i][j] = (j < i) ? 빈 : o;
                // 행의 인덱스가 0이면 모두 'O'로 채우고
                // 행의 인덱스가 1부터 열의 인덱스와 비교하여 채워질 칸을 채운다.
                // 열 < 행 조건식을 사용했을 경우
                // [1,0]  
                // [2,0] [2,1]
                // [3,0] [3,1] [3,2]
            }
        }
        return 문제2;  //만들어진 2차원 배열 문제2를 반환
    }


    private String[][] 문제3값() {
        String[][] 문제3 = new String[10][10];
        for(int i = 0; i < 문제3.length; i++) {
            for(int j = 0; j < 문제3[i].length; j++) {
                // j는 0
                // 0 ~ 8 < 9 (10) - 1 =행0
                // 0 ~ 7 < 8 (10) -2 =행1
                // 0 ~ 6 < 7 (10) -3 =행2
                if(j < (i+1)) {
                    문제3[i][j] = 빈;
                } else {
                    문제3[i][j] = o;
                }
                문제3[i][j] = (j < i) ? 빈 : o;
                // 행의 인덱스가 0이면 모두 'O'로 채우고
                // 행의 인덱스가 1부터 열의 인덱스와 비교하여 채워질 칸을 채운다.
                // 열 < 행 조건식을 사용했을 경우
                // [1,0]  
                // [2,0] [2,1]
                // [3,0] [3,1] [3,2]
            }
        }
        return 문제3;  //만들어진 2차원 배열 문제2를 반환
    }


    private void 배열확인(String[][] 배열) {
        for(int i = 0; i < 배열.length; i++) { 
            // 배열의 각 행을 하나씩 반복하면서
            for(int j = 0; j < 배열[i].length; j++) {
                // 각 행의 요소를 출력해
                System.out.print(배열[i][j]);
            }
            System.out.println(); // 한 행이 끝나면 줄바꿈
        }
    }

    private String[][] 문제4값() {
        String[][] 문제4 = new String[10][10];
        // 행   열      조건식( 열위치값 <= (열의길이 - 1) - 행위치값 )
        // 0    0~9     0 ~ 9 <= 9 (10 - 1) - 0 
        // 1    0~8     0 ~ 8 <= 8 (10 - 1) - 1
        // 2    0~7     0 ~ 7 <= 7 (10 - 1) - 2
        for(int i = 0; i < 문제4.length; i++) {
            for(int j = 0; j < 문제4[i].length; j++) {
                문제4[i][j] = (j <= (문제4[i].length -1) - i) ? o : 빈;
            }
            System.out.println();
        }
        return 문제4;
    }

}
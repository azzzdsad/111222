public class Study18_A {
    public Study18_A() {}
    public Study18_A(String msg) {
        System.out.println("전달 받은 내용 : " + msg);
        run();
    }
    public void run() {
        new Study18_B("B 안녕!");
    }
}


        // Q.1 자판기 프로그램을 만들기 위해서 필요한 기술은 무엇인가요? 
        // 1. 조건문(if) 2. 입출력관련 내용 3. 상품에 대한 정보
        // 4. 상품의 정보가 연계되는 자료형인 맵과 같은 데이터
        // 5. 조건문 6. 프로그램 언어인 자바 7. 2차원 배열

        // 추가 요구사항
        // 1. 반복 입력 받을 수 있도록 (반복문과 입력(System.in) 필수)
        // 2. 프로그램 시작 시 인사 말이 되도록 할 것.
        // 3. 프로그램 종료를 위해서 입력으로 "EXIT" 값으로 받으면 종료 되도록 할 것.
        
import java.util.HashMap;
import java.util.Map;

public class VendingMachine {
    public static void main(String[] args) {
        // 자판기에 음료와 가격을 설정
        Map<String, Integer> drinks = new HashMap<>();
        drinks.put("코카콜라", 2000);
        drinks.put("펩시콜라", 1800);
        drinks.put("칠성사이다", 2100);
        drinks.put("환타", 1800);
        drinks.put("나랑드사이다", 1400);

        // 사용자의 현금 및 카드 잔액 설정
        int userCash = 3000; // 현금
        int cardBalance = 5000; // 카드 잔액

        // 사용자가 선택한 결제 방법 ("현금" 또는 "카드")
        String paymentMethod = "카드"; // 현금을 원하면 "현금"으로 변경
        String selectedDrink = "환타";

        // 선택한 음료의 가격 가져오기
        if (drinks.containsKey(selectedDrink)) {
            int drinkPrice = drinks.get(selectedDrink);

            if (paymentMethod.equals("현금")) {
                // 현금 결제 처리
                if (userCash >= drinkPrice) {
                    int change = userCash - drinkPrice;
                    System.out.println(selectedDrink + "를 선택하셨습니다.");
                    System.out.println("가격: " + drinkPrice + "원");
                    System.out.println("잔돈: " + change + "원");
                } else {
                    System.out.println("현금이 부족합니다. 추가 금액이 필요합니다.");
                }
            } else if (paymentMethod.equals("카드")) {
                // 카드 결제 처리
                if (cardBalance >= drinkPrice) {
                    cardBalance -= drinkPrice; // 카드 잔액 차감
                    System.out.println(selectedDrink + "를 선택하셨습니다.");
                    System.out.println("가격: " + drinkPrice + "원");
                    System.out.println("결제가 완료되었습니다. 남은 카드 잔액: " + cardBalance + "원");
                } else {
                    System.out.println("카드 잔액이 부족합니다. 결제를 진행할 수 없습니다.");
                }
            } else {
                System.out.println("올바른 결제 방법을 선택해주세요. (현금 또는 카드)");
            }
        } else {
            System.out.println("선택하신 음료는 없습니다.");
        }
    }
}

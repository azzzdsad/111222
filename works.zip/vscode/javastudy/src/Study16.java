public class Study16 {
    int 일;
    int 이;
    public static void main(String[] args) {
        Study16 클래스 = new Study16(); // Study16 클래스의 객체를 생성하여 클래스라는 변수에 저장하는 코드
        System.out.println(클래스.일 + ", " + 클래스.이); // 클래스 객체의 일과 이 값을 ,로 구분하여 출력하는 코드
        클래스.b();
        System.out.println(클래스.일 + ", " + 클래스.이);
        /* 
        클래스.a의 값 출력
        
        int[] 배열 = 클래스.a();
        int 일 = 배열[0];
        int 이 = 배열[1];
         */
    }

    int[] a() {
        int 일 = 1;
        int 이 = 2;
        return new int[] {일,이};
    }

    // 클랙스.b의 값 출력
    void b() {
        일 = 10;
        이 = 20;
    }

    /* 
    기초 
    void a(){}
    int aa() {return 0;}
    string aaa() {return "";}
    */
}
public class Study02 {
    public static void main(String[] ar) {
    int a = 1;
    int b = 5;
    System.out.println(a);
    System.out.println(b);
    }

}

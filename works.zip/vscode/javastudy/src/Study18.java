public class Study18 {
    public static void main(String[] args) {
        //Study18_A s18A = new Study18_A()
        // s18A.run();
        new Study18_A().run();
    }
}
    
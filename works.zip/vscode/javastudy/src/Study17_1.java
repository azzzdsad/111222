


public class Study17_1 {
    
    int a;
    int b;
    public Study17_1() {}
    public Study17_1(int a, int b) {
        this.a = a;
        this.b = b;
    }
    public String toString() {
        return "a: " +a + ", b: " + b ;
    }
}
public class Study17_3 extends AA {
    
    public void print(String txt) {
        System.out.println("Study17_3 > " + txt);
    }
}
class AA {
    public void print(String txt) {
        System.out.println("AA > " + txt);
    }
}
public class Study13 {
    
    public static void main(String[] args) {
        String[] 단1 = new String[9]; 
        int[] 단1값 = new int[9];

        for(int i = 1; i <= 단1.length; i++) {
            단1값[i-1] = (1*i);
            System.out.println(1 + "*" + i + "=" + (1*1));  
            단1[i-1] = (1 + "*" + i + "=" + (1*1)); //0부터 0까지 나옴, index를 만드려고 i에다가 -1을 함
            System.out.println(단1[i-1]);
            System.out.println(단1[i-1]);
        }
    }
}
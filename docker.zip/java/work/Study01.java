public class Study01 {
    System.out.println("안녕");
}

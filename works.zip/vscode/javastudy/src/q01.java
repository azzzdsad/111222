

public class q01 {
    
    public static void main(String[] args) {

        //1번 문제

        int a = 10;
        boolean b = false;
        //System.out.print((a + b));
        //인트(정수)와 부린(논리 값)은 서로 다른 데이터 타입으로, 직접 더할 수 없음
        // a + b는 연산이 아니기 때문에 컴파일 에러가 발생
        System.out.print("a: " + a + ", b: " + b);
        //boolean 값을 그대로 출력하고 싶다면 숫자로 변환하지 않고, 별도의 문장을 작성하는 것도 가능합니다.
        
}

}


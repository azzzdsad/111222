public class Study18_B {
    public Study18_B(String msg) {
        System.out.println("전달 받은 내용 : " + msg);
        run();
    }
    public void run() {
        new Study18_A("A 안녕하세요.");
    }
}

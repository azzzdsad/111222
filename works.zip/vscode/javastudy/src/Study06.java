public class Study06 {

        public static void main(String[] args) {
            //계산기
            int a = 5;
            int b = 3;

            int 합 = (a+b);  // 5 + 3 = 8
            int 빼기 = (a-b);  // 5 - 3 = 2
            int 곱 = (a*b);  
            int 나누기 = (a/b);
            int 나머지 = (a%b);

            System.out.println(합);
            System.out.println(빼기);
            System.out.println(곱);
            System.out.println(나누기);
            System.out.println(나머지);

        }


}
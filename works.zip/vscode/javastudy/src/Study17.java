/* Study17
 * Study17_1
 * Study17_2
 * Study17_3
 * 총 4개의 파일은 연동되어 있음
 * 참고 주소
 * https://chatgpt.com/c/6743ee57-245c-8013-9545-72f4de876e93
 */


public class Study17 {
    public static void main(String[] args) {
        Study17_1 s15_1 = new Study17_1();
        System.out.println(s15_1);
    }
        // Study17_1 s17_1 = new Study17_1();
        // System.out.println(s17_1);
        // Study17 s17 = new Study17();
        // s17.a = 10;
        // s17.b = 2;
        // s17.더하기();
        // s17.빼기();
        // s17.빼기(5, 3);
        // Study17_2 s17_2 = new Study17_2(10, 2);
        // s17_2.더하기();
        // s17_2.빼기();
        // s17_2.빼기(5, 3);
        // System.out.println(s17_2.a);
        // s17_2.a = 30;
        // System.out.println(s17_2.a);
        // System.out.println(s17_2);
        Study17_3 s17_3 = new Study17_3();
        s17_3.print("출력 내용");
    }    
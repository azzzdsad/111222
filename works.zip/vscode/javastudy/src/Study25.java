
import java.util.HashMap;
import java.util.Map;

public class Study25 {
    public static void main(String[] args) {
        Map map = new HashMap<>(); // Map과 HashMap도 import를 써야 함
        map.put("no", 1);
        map.put("name", "홍길동");
        System.out.println( map.get("no") );
        System.out.println( map.size() );
        map.remove("no");
        System.out.println(map);
    }
}
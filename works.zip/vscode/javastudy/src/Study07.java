public class Study07 {
    public static void main(String[] args) {
        int a = 5;
        int b = 3;

        /*
        if (a == b) {
            // == 뜻은 같은가?(비교)라는 뜻, a와 b의 값이 같으면 참으로 출력하기
            System.out.println("참된");
        }

        if(a != b) { //a와 b의 값이 같지 않으면 같지않다로 출력하기
            System.out.println("같지않다");
            //재생 버튼 누르면 확인 됨 
        }

        boolean c = true;

        if(c) { //if 옆에 괄호 부분에 논리형 값이 들어갈 수 있음
            System.out.println("진실");
            System.out.println("거짓");

        }

        System.out.println(a==b);
        System.out.println(a !=b);

        */

        if(a == b) { // a=5, b=3, if와 else는 반복할 수 없음
        } else if(a <= b) {

        } else if(a <= b) {

        } else if(a <= b) {
            System.out.println("참");

        }

    }
}
